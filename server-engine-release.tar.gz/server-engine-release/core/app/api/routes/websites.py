import uuid
import re
import json
import time
import os
import subprocess
import urllib.request
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from app.api.dependencies import require_user
from app.services.account_isolation import account_isolation
from app.models.website import WebsiteActionRequest, WebsiteCreateRequest, WebsiteDeployRequest, WebsiteDirectoryRequest, WebsiteDomainCheckRequest, WebsiteUpdateRequest
from app.services.job_service import job_store
from app.services.service_runtime import composer_path, ensure_composer_launcher, php_cli_path, php_runtime_library_path, service_root
from app.services.website_service import website_service

router = APIRouter(prefix="/api/v1/websites", tags=["websites"])
_wordpress_versions: tuple[float, list[str]] = (0, [])
_laravel_versions: tuple[float, list[str]] = (0, [])
_WEBSITE_ROOT = Path(os.getenv("SE_WEBSITE_ROOT", "/server-engine/www")).resolve()


def _require_site(website_id: str, user):
    account_isolation.assert_access(user, "website", website_id)
    site = website_service.get(website_id)
    if site is None:
        raise HTTPException(status_code=404, detail="Website not found")
    return site


def _account_path_allowed(path: str, user) -> None:
    account = account_isolation.account_for_user(user)
    if not account:
        return
    try:
        Path(path).expanduser().resolve().relative_to(Path(account["home_path"]).resolve())
    except ValueError as error:
        raise HTTPException(status_code=403, detail="This path is outside the hosting account home") from error


def _website_project_path_allowed(path: str, user) -> None:
    try:
        resolved = Path(path).expanduser().resolve()
        resolved.relative_to(_WEBSITE_ROOT)
    except ValueError as error:
        raise HTTPException(status_code=403, detail=f"Website project folders must be inside {_WEBSITE_ROOT}") from error
    if resolved == _WEBSITE_ROOT:
        raise HTTPException(status_code=400, detail=f"Choose a project subfolder inside {_WEBSITE_ROOT}; the website root itself cannot be used.")
    _account_path_allowed(path, user)


def _php_runtime_release(version: str) -> str:
    """Return the actual PHP release string, including beta/RC suffixes."""
    cli = php_cli_path(version)
    root = service_root("php", version)
    try:
        result = subprocess.run(
            [str(cli), "-n", "-r", "echo PHP_VERSION;"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
            env={**os.environ, "LD_LIBRARY_PATH": php_runtime_library_path(root)},
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return (result.stdout or "").strip()


def _queue_provider_reload(site):
    """Queue one provider reload while an identical reload is already active."""
    expected = ("Reload nginx" if site.server_type == "nginx" else f"Restart {site.server_type}").lower()
    if any(job.status in {"queued", "running"} and job.type.lower() == expected for job in job_store.list()):
        return
    job_store.enqueue_action(f"provider-reload-site-{site.id}-{uuid.uuid4().hex[:8]}", site.server_type, "restart")


class WebsiteConfigurationSaveRequest(BaseModel):
    content: str = Field(max_length=200000)


class WebsiteConfigurationRestoreRequest(BaseModel):
    restore: str


class WebsiteCertificateRequest(BaseModel):
    method: str = Field(pattern="^(acme|upload)$")
    email: str = Field(default="", max_length=320)
    staging: bool = False
    certificate: str = Field(default="", max_length=200000)
    private_key: str = Field(default="", max_length=200000)
    chain: str = Field(default="", max_length=200000)


@router.get("")
def list_websites(user=Depends(require_user)):
    sites = website_service.list()
    owned = account_isolation.filter_owned(user, "website", [site.id for site in sites])
    visible = sites if owned is None else [site for site in sites if site.id in owned]
    return [{**site.model_dump(mode="json"), "certificate": website_service.certificate_info(site)} for site in visible]


@router.get("/directories")
def list_directories(path: str | None = None, recursive: bool = False, user=Depends(require_user)):
    if path:
        _account_path_allowed(path, user)
    return website_service.directories(path, recursive)


@router.get("/directories/status")
def project_directory_status(path: str, user=Depends(require_user)):
    _account_path_allowed(path, user)
    return website_service.project_path_status(path)


@router.post("/check-domain")
def check_website_domain(payload: WebsiteDomainCheckRequest, user=Depends(require_user)):
    website_service.check_domains(payload.domain, payload.aliases)
    return {"available": True}


@router.post("/directories", status_code=status.HTTP_201_CREATED)
def create_directory(payload: WebsiteDirectoryRequest, user=Depends(require_user)):
    _account_path_allowed(payload.path, user)
    return website_service.create_directory(payload.path, payload.name)


@router.get("/wordpress/versions")
def wordpress_versions(user=Depends(require_user)):
    global _wordpress_versions
    if time.time() - _wordpress_versions[0] < 3600 and _wordpress_versions[1]:
        return _wordpress_versions[1]
    versions = ["latest"]
    try:
        request = urllib.request.Request("https://api.wordpress.org/core/version-check/1.7/", headers={"User-Agent": "Server-Engine-Control-Panel"})
        with urllib.request.urlopen(request, timeout=8) as response:
            payload = json.loads(response.read().decode("utf-8"))
        versions.extend(str(item.get("version", "")).strip() for item in payload.get("offers", []) if item.get("version"))
    except Exception:
        pass
    _wordpress_versions = (time.time(), list(dict.fromkeys(versions)))
    return _wordpress_versions[1]


@router.get("/laravel/versions")
def laravel_versions(user=Depends(require_user)):
    """Return stable Laravel application versions from Packagist, cached briefly."""
    global _laravel_versions
    if time.time() - _laravel_versions[0] < 3600 and _laravel_versions[1]:
        return _laravel_versions[1]
    versions = []
    try:
        request = urllib.request.Request(
            "https://repo.packagist.org/p2/laravel/laravel.json",
            headers={"User-Agent": "Server-Engine-Control-Panel"},
        )
        with urllib.request.urlopen(request, timeout=8) as response:
            payload = json.loads(response.read().decode("utf-8"))
        for package in payload.get("packages", {}).get("laravel/laravel", []):
            version = str(package.get("version", "")).removeprefix("v")
            if re.fullmatch(r"\d+\.\d+(?:\.\d+)?", version):
                versions.append(version)
    except Exception:
        pass
    versions = sorted(set(versions), key=lambda value: tuple(int(part) for part in value.split(".")), reverse=True)
    _laravel_versions = (time.time(), versions)
    return versions


@router.get("/{website_id}/configuration")
def get_website_configuration(website_id: str, server_type: str | None = None, user=Depends(require_user)):
    site = _require_site(website_id, user)
    result = website_service.configuration(site, server_type)
    path = Path(result["config_path"])
    if path.exists():
        result["content"] = path.read_text(errors="replace")
    provider = server_type or (site.server_type if site else "")
    backup = website_service.config_backup_root / website_service._configuration_id(site) / f"{provider}.previous" if site else None
    result["has_previous"] = bool(backup and backup.exists())
    return result


@router.put("/{website_id}/configuration")
def save_website_configuration(website_id: str, payload: WebsiteConfigurationSaveRequest, server_type: str | None = None, user=Depends(require_user)):
    site = _require_site(website_id, user)
    provider = server_type or site.server_type
    result = website_service.save_provider_configuration(website_id, provider, payload.content)
    _queue_provider_reload(site)
    result["saved"] = True
    return result


@router.post("/{website_id}/configuration/restore")
def restore_website_configuration(website_id: str, payload: WebsiteConfigurationRestoreRequest, server_type: str | None = None, user=Depends(require_user)):
    site = _require_site(website_id, user)
    provider = server_type or site.server_type
    result = website_service.restore_provider_configuration(website_id, provider, payload.restore)
    _queue_provider_reload(site)
    result["restored"] = payload.restore
    return result


@router.get("/{website_id}")
def get_website(website_id: str, user=Depends(require_user)):
    site = _require_site(website_id, user)
    return {**site.model_dump(mode="json"), "certificate": website_service.certificate_info(site)}


@router.get("/{website_id}/certificate")
def get_website_certificate(website_id: str, user=Depends(require_user)):
    site = _require_site(website_id, user)
    return website_service.certificate_info(site)


@router.post("/{website_id}/certificate", status_code=status.HTTP_202_ACCEPTED)
def request_website_certificate(website_id: str, payload: WebsiteCertificateRequest, user=Depends(require_user)):
    site = _require_site(website_id, user)
    if payload.method == "upload" and (not payload.certificate.strip() or not payload.private_key.strip()):
        raise HTTPException(400, "Certificate and private key are required for upload.")
    return {"job": job_store.enqueue_certificate(f"website-certificate-{uuid.uuid4().hex}", website_id, payload.method, payload.email, payload.staging, payload.certificate, payload.private_key, payload.chain).model_dump(mode="json")}


@router.post("", status_code=status.HTTP_201_CREATED)
def create_website(payload: WebsiteCreateRequest, user=Depends(require_user)):
    account_isolation.assert_quota(user, "website")
    _website_project_path_allowed(payload.project_path, user)
    site = website_service.create(payload)
    account_isolation.claim(user, "website", site.id, check_quota=False)
    _queue_provider_reload(site)
    job_store.publish({"type": "websites-updated", "action": "created", "website_id": site.id})
    return site


@router.post("/deploy", status_code=status.HTTP_202_ACCEPTED)
def deploy_website(payload: WebsiteDeployRequest, user=Depends(require_user)):
    """Create the website profile, then deploy the selected application serially."""
    if not payload.php_version or not php_cli_path(payload.php_version).exists():
        raise HTTPException(400, "Install a PHP runtime and select it before deploying this application.")
    if payload.application_template == "laravel":
        runtime_release = _php_runtime_release(payload.php_version)
        if re.search(r"(?:alpha|beta|rc)\d*", runtime_release, re.IGNORECASE):
            raise HTTPException(
                400,
                f"Laravel dependencies require a stable PHP runtime. PHP {runtime_release or payload.php_version} is a prerelease; choose PHP 8.5.x or another stable version.",
            )
    database_required = payload.application_template in {"wordpress", "drupal"}
    if database_required:
        payload.database_enabled = True
        if payload.database_engine != "mysql":
            raise HTTPException(400, f"{payload.application_template.title()} requires a running MySQL service. Start MySQL and select it before deploying.")
        if not payload.database_name.strip():
            raise HTTPException(400, f"A {payload.application_template.title()} database name is required.")
        if not payload.database_user.strip():
            raise HTTPException(400, f"A {payload.application_template.title()} database owner is required.")
    account_isolation.assert_quota(user, "website")
    _website_project_path_allowed(payload.project_path, user)
    project_status = website_service.project_path_status(payload.project_path)
    if project_status["exists"] and (not project_status["is_directory"] or not project_status["is_empty"]):
        raise HTTPException(400, "Project folder is not empty. Choose a new domain or project folder before deploying.")
    if payload.application_template != "wordpress":
        ensure_composer_launcher()
    if payload.application_template != "wordpress" and not composer_path().exists():
        raise HTTPException(400, "Install Composer before deploying this PHP application.")
    if payload.database_enabled and payload.database_engine != "mysql":
        raise HTTPException(400, "One-click database provisioning currently supports running MySQL only.")
    if payload.database_enabled and not payload.database_name.strip():
        raise HTTPException(400, "A database name is required when database attachment is enabled.")
    if payload.database_enabled and not payload.database_user.strip():
        raise HTTPException(400, "A database user is required when database attachment is enabled.")
    if payload.application_template == "wordpress" and payload.framework != "wordpress":
        payload.framework = "wordpress"
    if payload.application_template == "laravel" and payload.framework != "laravel":
        payload.framework = "laravel"
    if payload.application_template == "laravel" and payload.laravel_version and not re.fullmatch(r"[0-9A-Za-z.*^~_-]+", payload.laravel_version):
        raise HTTPException(400, "The Laravel version is invalid.")
    if payload.application_template in {"wordpress", "drupal"}:
        application_name = payload.application_template.title()
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,63}", payload.wordpress_admin_user.strip()):
            raise HTTPException(400, f"{application_name} admin username must start with a letter and use only letters, numbers, hyphens, and underscores.")
        if len(payload.wordpress_admin_password) < 10:
            raise HTTPException(400, f"{application_name} admin password must contain at least 10 characters.")
        if not payload.wordpress_site_title.strip():
            raise HTTPException(400, f"{application_name} site title is required.")
        if not payload.notes.strip():
            raise HTTPException(400, f"{application_name} site description is required.")
    if payload.application_template == "wordpress":
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,31}", payload.wordpress_database_prefix.strip()):
            raise HTTPException(400, "WordPress database prefix is invalid.")
    site = website_service.create(payload)
    account_isolation.claim(user, "website", site.id, check_quota=False)
    job = job_store.enqueue_application_deploy(
        f"website-deploy-{uuid.uuid4().hex}",
        site,
        payload.application_template,
        payload.database_engine,
        payload.database_password,
        payload.wordpress_version,
        payload.wordpress_admin_user,
        payload.wordpress_admin_password,
        payload.wordpress_database_prefix,
        payload.wordpress_site_title,
        payload.laravel_version,
        cleanup_project_on_failure=not project_status["exists"] or project_status["is_empty"],
    )
    return {"website": site, "job": job}


@router.patch("/{website_id}")
def update_website(website_id: str, payload: WebsiteUpdateRequest, user=Depends(require_user)):
    _require_site(website_id, user)
    if getattr(payload, "project_path", None):
        _website_project_path_allowed(payload.project_path, user)
    site = website_service.update(website_id, payload)
    # Configuration changes, including maintenance mode, must be loaded by
    # the active provider immediately. The action is serialized with other
    # service operations and its result is delivered over the shared jobs
    # socket; the PATCH response remains the website record for compatibility.
    _queue_provider_reload(site)
    job_store.publish({"type": "websites-updated", "action": "updated", "website_id": site.id})
    return site


@router.post("/{website_id}/actions")
def website_action(website_id: str, payload: WebsiteActionRequest, user=Depends(require_user)):
    _require_site(website_id, user)
    return website_service.action(website_id, payload.action)


@router.delete("/{website_id}")
def delete_website(website_id: str, remove_files: bool = False, user=Depends(require_user)):
    _require_site(website_id, user)
    website_service.delete(website_id, remove_files)
    account_isolation.release("website", website_id)
    job_store.publish({"type": "websites-updated", "action": "deleted", "website_id": website_id})
    return {"deleted": True}
